# PATCH_NOTES_v1.2.9w31

## Summary
- Canonicalized ignored-evidence QC normalization to map legacy `qc_status` into `qc_source` deterministically.
- Centralized stable JSON serialization in the DI integrity authority and routed callers through it.
- Deduplicated `_parse_iso` and `_qc_status_from_flag` into a shared DI helper.
- Clarified context usage in DI docs/CLI and removed silent snapshot lineage fallback.
- Bumped PSI_VERSION to `v1.2.9w31`.

## Deterministic-Safe Rationale
- Stable JSON serialization now has a single authority (`psi.services.di.integrity.stable_json_dumps`) with fixed settings: `sort_keys=True`, `separators=(",", ":")`, `ensure_ascii=False`.
- Ignored-evidence normalization uses deterministic field mapping and ordering, with explicit coercions and no dependence on dict iteration order.
- Shared ISO parsing/QC flag mapping preserves existing behavior exactly while eliminating divergent local copies.
- Lineage fallback removal prevents nondeterministic or guessed program lineage from being snapshotted.
- No DB schema changes or mutable snapshot rewrites were introduced.

## Backwards-Compat Normalization Rules
- Ignored evidence accepts legacy `qc_status` and maps it to canonical `qc_source` when `qc_source` is missing/empty.
- `qc_flag` legacy values map to QC status as before: empty/0 -> `unreviewed`, pass/ok -> `approved`, fail/flagged -> `rejected`, quarantine -> `quarantined`, else `unknown`.
- ISO8601 timestamps with trailing `Z` are normalized to `+00:00` before parsing.

## Files Touched
- `psi/services/di/shared.py`
- `psi/services/di/comparability.py`
- `psi/services/di/selectors.py`
- `psi/services/di/soe.py`
- `psi/services/di/verify.py`
- `psi/services/di/compute.py`
- `psi/services/di/runner.py`
- `psi/services/decisions.py`
- `psi/tools/di_replay_regression.py`
- `psi/tools/di_cross_version_stress.py`
- `psi/tools/verify_snapshot.py`
- `psi/tools/run_di.py`
- `docs/DI_SNAPSHOT_CONTRACT.md`
- `psi/version.py`
