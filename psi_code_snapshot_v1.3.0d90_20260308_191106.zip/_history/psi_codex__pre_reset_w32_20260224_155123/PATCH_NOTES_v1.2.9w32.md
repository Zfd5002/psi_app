# PATCH_NOTES_v1.2.9w32

## Summary
- Added DI molecule-scope foundation: deterministic batch resolution, cross-batch evidence aggregation, and molecule-safe selection provenance.
- Extended SoE v0.2/v0.3 and comparability handling to support molecule scope deterministically.
- Updated DIInput validation and tooling to allow `scope_type="molecule"`.
- Added molecule-scope coverage smoke test and bumped PSI_VERSION to `v1.2.9w32`.

## Molecule Scope Rules
- `scope_type="molecule"` uses `scope_id` as the molecule id.
- Candidate batches are resolved from `batches` by `molecule_id`, ordered by `created_at ASC, id ASC`.
- Selection aggregates across all candidate batches:
  - Per-batch selection uses existing batch selector logic (QC filtering, ignore_for_model, primary/recency tie-break).
  - Molecule-level selection picks the deterministic best candidate per metric across batches.
  - Non-chosen per-batch candidates are recorded as ignored with `superseded_by_primary` or `superseded_by_newer`.
- `outputs_json.provenance.selection_provenance` records:
  - `batch_ids` (ordered)
  - `selected_batch_ids`
  - `omitted_batches` with deterministic reasons
  - `batch_ordering` and selection mode details

## Determinism Considerations
- Batch ordering is explicit and stable: `created_at ASC, id ASC`.
- Molecule selection uses deterministic evidence ordering: primary first, then newest timestamp, then smallest measurement id.
- All JSON surfaces continue to use `psi.services.di.integrity.stable_json_dumps` for hashing and ordering.
- SoE v0.2/v0.3 for molecule uses deterministic union of batch evidence with stable ordering.

## Not Included
- No ranking/shortlisting changes (deferred to w33).
- No new DI templates.
- No destructive DB changes.

## Files Changed
- `psi/core/di/schema.py`
- `psi/services/di/selectors.py`
- `psi/services/di/selection.py`
- `psi/services/di/comparability.py`
- `psi/services/di/soe.py`
- `psi/services/di/compute.py`
- `psi/services/di/runner.py`
- `psi/tools/run_di.py`
- `psi/tools/di_contract_smoke.py`
- `docs/DI_SNAPSHOT_CONTRACT.md`
- `psi/version.py`
